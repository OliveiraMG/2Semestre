/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade02.ac01;

/**
 *
 * @author theus
 */
public class CalculoAluno {
    
    Double calcularMedia(Double nota1, Double nota2) {
    return (nota1 * 0.4) + (nota2 * 0.6);
    }
    
}
